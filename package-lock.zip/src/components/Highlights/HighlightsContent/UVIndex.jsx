import React from 'react'

const UVIndex = ({current}) => {
    const {uvi} =current;
    return (
      <div className="content">
          {uvi}
      </div>)
}

export default UVIndex