import React from 'react'

const DayWeather = () => {
  return (
    <div>DayWeather</div>
  )
}

export default DayWeather